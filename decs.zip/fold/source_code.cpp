#include<bits/stdc++.h>
using namespace std;

signed main(){
	int arr[5];
	for(int i=0;i<6;i++){
		arr[i]=i;
		arr[i]+=1;
	}
	cout<<arr[-1]/0;
}  

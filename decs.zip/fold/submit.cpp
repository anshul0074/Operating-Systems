#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <chrono>
#include <thread>

std::string generateRequestId() {
    static int requestIdCounter = 0;
    std::time_t now = std::time(0);
    return std::to_string(now) + "_" + std::to_string(requestIdCounter++);
}

void measureResponseTime(struct timeval& tsend, struct timeval& trecv) {
    gettimeofday(&trecv, NULL);
    long elapsed = (trecv.tv_sec - tsend.tv_sec) * 1000000 + trecv.tv_usec - tsend.tv_usec;
    std::cout << "Response time: " << elapsed << " microseconds\n";
}

int main(int argc, char* argv[]) {
    if (argc != 6) {
        std::cerr << "Usage: " << argv[0] << " <new|status> <serverIP:port> <sourceCodeFileTobeGraded|requestID> <loopNum> <sleepTimeSeconds>" << std::endl;
        return 1;
    }

    std::string serverAddress = argv[2];
    std::string sourceCodeFileName = argv[3];
    int loopNum = std::stoi(argv[4]);
    int sleepTimeSeconds = std::stoi(argv[5]);

    std::string requestId;

    if (strcmp(argv[1], "new") == 0) {
        requestId = generateRequestId();
        std::cout << requestId << "\n";
    } else if (strcmp(argv[1], "status") == 0) {
        requestId = argv[3];
    } else {
        std::cerr << "Invalid command. Use 'new' or 'status'." << std::endl;
        return 1;
    }

    std::ifstream sourceCodeFile(sourceCodeFileName);
    std::string sourceCode((std::istreambuf_iterator<char>(sourceCodeFile)), std::istreambuf_iterator<char>());

    struct timeval tsend, trecv;

    for (int i = 0; i < loopNum; ++i) {
        gettimeofday(&tsend, NULL);

        int clientSocket = socket(AF_INET, SOCK_STREAM, 0);
        if (clientSocket == -1) {
            std::cerr << "Socket creation error." << std::endl;
            return 1;
        }

        struct sockaddr_in serverAddr;
        serverAddr.sin_family = AF_INET;
        serverAddr.sin_port = htons(atoi(serverAddress.substr(serverAddress.find(":") + 1).c_str()));
        inet_pton(AF_INET, serverAddress.substr(0, serverAddress.find(":")).c_str(), &serverAddr.sin_addr);

        if (connect(clientSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == -1) {
            std::cerr << "Connection to server failed." << std::endl;
            return 1;
        }

        std::string requestData = requestId + "\n" + sourceCode;
        if (send(clientSocket, requestData.c_str(), requestData.size(), 0) == -1) {
            std::cerr << "Sending source code to server failed." << std::endl;
            close(clientSocket);
            return 1;
        }

        char response[1024];
        if (recv(clientSocket, response, sizeof(response), 0) == -1) {
            std::cerr << "Receiving response from server failed." << std::endl;
        } else {
            std::cout << response;
        }

        measureResponseTime(tsend, trecv);

        close(clientSocket);

        std::this_thread::sleep_for(std::chrono::seconds(sleepTimeSeconds));
    }

    return 0;
}

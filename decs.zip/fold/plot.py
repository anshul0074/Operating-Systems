import subprocess
import matplotlib.pyplot as plt

def run_load_test(num_clients, loop_num, sleep_time):
    subprocess.run(['./load.sh','localhost' , str(num_clients), str(loop_num), str(sleep_time)])

def plot_results(x_values, y_values, xlabel, ylabel, title):
    plt.plot(x_values, y_values, marker='o')
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.title(title)
    plt.grid(True)
    plt.savefig("figure.png")

def main():
    num_clients_values = [1, 5 , 10 , 15, 20]  # Adjust as needed
    loop_num = 2  # Adjust as needed
    sleep_time = 1  # Adjust as needed

    average_response_times = []
    overall_throughputs = []

    for num_clients in num_clients_values:
        run_load_test(num_clients, loop_num, sleep_time)

        # Parse the results from the load test output
        output = subprocess.check_output(['./load.sh','localhost', str(num_clients), str(loop_num), str(sleep_time)], text=True)
        average_response_time = (output.split("Average Response Time: ")[1].split(" microseconds")[0])
        overall_throughput = (output.split("Overall Throughput: ")[1].split(" requests/second")[0])
        print(int(average_response_time))
        print(int(overall_throughput))
        average_response_times.append(average_response_time)
        overall_throughputs.append(overall_throughput)

    # Plotting
    plot_results(num_clients_values, average_response_times, 'Number of Clients', 'Average Response Time (microseconds)', 'Number of Clients vs Average Response Time')
    plot_results(num_clients_values, overall_throughputs, 'Number of Clients', 'Overall Throughput (requests/second)', 'Number of Clients vs Overall Throughput')

if __name__ == "__main__":
    main()

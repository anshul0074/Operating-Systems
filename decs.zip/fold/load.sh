#!/bin/bash

SERVER_IP=$(nslookup "$1" | awk '/^Address: / { print $2; exit }')
if [ -n "$SERVER_IP" ]; then
    echo "Starting simulation with $1"
else
    echo "Unable to resolve the IP address of $1"
    exit 1
fi
if [ "$#" -ne 4 ]; then
    echo "Usage: $0 localhost <numClients> <loopNum> <sleepTimeSeconds>"
    exit 1
fi

NUM_CLIENTS=$2
LOOP_NUM=$3
SLEEP_TIME=$4
mkdir -p simulation_results
for ((i=1; i<=$NUM_CLIENTS; i++)); do
    (./submit new "$SERVER_IP":8080 source_code.cpp $LOOP_NUM $SLEEP_TIME > "simulation_results/output_$i.txt")  &
done

wait

totalThroughput=0
totalResponseTime=0
totalSamples=0

for ((i=1; i<=$NUM_CLIENTS; i++)); do
    responseTimes=$(grep "Response time:" simulation_results/output_$i.txt | awk '{print $3}' | tr '\n' ' ')
    samples=$(echo "$responseTimes" | wc -w)

    totalThroughput=$((totalThroughput + samples))
    #temp= $(echo $responseTimes | tr ' ' '\n' | paste -sd+ | bc)
    totalResponseTime=$((totalResponseTime + $(echo $responseTimes | tr ' ' '\n' | paste -sd+ | bc)))
    totalSamples=$((totalSamples + samples))
    totalSamples=$((totalSamples + samples))
done

overallThroughput=$((totalThroughput / LOOP_NUM))
averageResponseTime=$((totalResponseTime / totalSamples))

echo "Overall Throughput: $overallThroughput requests/second"
echo "Average Response Time: $averageResponseTime microseconds"

#include <iostream>
#include <fstream>
#include <cstring>
#include <unistd.h>
#include <netinet/in.h>
#include <pthread.h>
#include <queue>
#include <map>
#include<sys/time.h>

#define QUEUE_SIZE 20

std::queue<int> taskQueue;
int taskCount = 0;
const int BUFFER_SIZE = 1024;
const int MAX_FILE_SIZE_BYTES = 4;
pthread_mutex_t queueMutex;
pthread_mutex_t taskMutex;
pthread_cond_t taskReady;
bool done = false;
std::string s="";
struct GradingRequest {
    int id;
    std::string programFile;
    std::string execFile;
    std::string status;
};

std::map<int, GradingRequest> gradingRequests;
const std::string logFilePath = "grading_log.txt";

void masterFunc(int sockfd);
void *grader(int sockfd);
void checkStatus(int sockfd, int requestId);

// Function to generate a unique request ID
int generateRequestId() {
    srand(static_cast<unsigned>(time(nullptr)));
    return rand();
}
void error(const char *msg) {
    perror(msg);
    exit(1);
}
int recv_file(int sockfd, const std::string &file_path) {
    char buffer[BUFFER_SIZE];
    bzero(buffer, BUFFER_SIZE);

    std::ofstream file(file_path, std::ios::binary);
    if (!file) {
        perror("Error opening file");
        return -1;
    }

    // Buffer for getting file size as bytes
    char file_size_bytes[MAX_FILE_SIZE_BYTES];

    // First receive file size bytes
    if (recv(sockfd, file_size_bytes, sizeof(file_size_bytes), 0) == -1) {
        perror("Error receiving file size 1");
        return -1;
    }

    int file_size;
    // Copy bytes received into the file size integer variable
    memcpy(&file_size, file_size_bytes, sizeof(file_size_bytes));

    // Some local printing for debugging
    printf("File size is: %d\n", file_size);

    // Now start receiving file data
    size_t bytes_read = 0, total_bytes_read = 0;
    //std::string s="";
    while (true) {
        // Read max BUFFER_SIZE amount of file data
        bytes_read = recv(sockfd, buffer, BUFFER_SIZE, 0);

        // Total number of bytes read so far
        total_bytes_read += bytes_read;

        if (bytes_read <= 0) {
            perror("Error receiving file data");
            return -1;
        }

        // Write the buffer to the file
        file.write(buffer, bytes_read);
        s+=buffer;
        // Reset buffer
        bzero(buffer, BUFFER_SIZE);

        // Break out of the reading loop if read file_size number of bytes
        if (total_bytes_read >= file_size)
            break;
    }
    std::cout<<s<<"\n";
    if(s[0]=='X'){
        return 1;
    }
    // File will be automatically closed when 'file' goes out of scope
    return 0;
}
// Function to save results to a log file
void saveResults(int id, const std::string &result) {
    std::ofstream logFile(logFilePath, std::ios::app);
    logFile << "Request ID: " << id << "\n";
    logFile << result << "\n\n";
    logFile.close();
}

std::string compile_command(int id, const std::string &programFile, const std::string &execFile) {
    std::string command = "g++ -o " + execFile + "  " + programFile + " 2> compiler_err" + std::to_string(id) + ".txt";
    std::cout << command << std::endl;
    return command;
}

std::string run_command(int id, const std::string &execFileName) {
    std::string command = "./" + execFileName + " > out" + std::to_string(id) + ".txt 2> runtime_err" + std::to_string(id) + ".txt";
    std::cout << command << std::endl;
    return command;
}

std::string makeProgramFileName(int id) {
    return "file" + std::to_string(id) + ".cpp";
}

std::string makeExecFileName(int id) {
    return "prog" + std::to_string(id);
}
void *grader(int sockfd, int requestId) {
    int newsockfd =(sockfd);

    int n;

    std::string programFile = makeProgramFileName(static_cast<int>(pthread_self()));
    std::string execFile = makeExecFileName(static_cast<int>(pthread_self()));

    std::cout << programFile << "  " << execFile << std::endl;
    int x=recv_file(newsockfd, programFile);
    if(x==1){
        std::string tmp="";
        for(int i=1;i<s.size();i++){
            tmp+=s[i];
        }
        int requestId=stoi(tmp);
        if(gradingRequests.find(requestId)!=gradingRequests.end()){
            std::string status= gradingRequests[requestId].status;
            n = send(newsockfd, status.c_str(), status.size(), 0);
            close(newsockfd);
        }
        return nullptr;
    }
    if (x!=0) {
        close(newsockfd);
        return nullptr;
    }

    // Some progress response
    n = send(newsockfd, "I got your code file for grading\n", 33, 0);

    std::string comp_command = compile_command(static_cast<int>(pthread_self()), programFile, execFile);
    std::string r_command = run_command(static_cast<int>(pthread_self()), execFile);

    if (system(comp_command.c_str()) != 0) {
        n = send(newsockfd, "COMPILER ERROR\n", 16, 0);
        if (n < 0)
            error("ERROR writing to socket");
        close(newsockfd);
        gradingRequests[requestId].status = "Compile Error";
    } else if (system(r_command.c_str()) != 0) {
        n = send(newsockfd, "RUNTIME ERROR\n", 15, 0);
        if (n < 0)
            error("ERROR writing to socket");
        close(newsockfd);
        gradingRequests[requestId].status = "Runtime Error";
    } else {
        n = send(newsockfd, "PROGRAM RAN\n", 13, 0);
        if (n < 0)
            error("ERROR writing to socket");
        close(newsockfd);
        gradingRequests[requestId].status= "Completed";
    }
    saveResults(requestId, gradingRequests[requestId].status);


    return nullptr;
}
void *workerFunc(void* arg) {
    while (true) {
        int item;
        pthread_mutex_lock(&queueMutex);
        while (taskCount == 0 && !done) {
            pthread_cond_wait(&taskReady, &queueMutex);
        }
        if (taskCount > 0) {
            item = taskQueue.front();
            taskQueue.pop();
            taskCount--;
            pthread_cond_signal(&taskReady);
        }
        pthread_mutex_unlock(&queueMutex);
        if (done == true && taskCount == 0) {
            break;
        }
        int x = static_cast<int>(reinterpret_cast<std::uintptr_t>(arg));
        grader(item,x);
    }
    return nullptr;
}

void masterFunc(int sockfd) {
    pthread_mutex_lock(&queueMutex);
    while ((taskQueue.size() + 1) > QUEUE_SIZE && !done) {
        pthread_cond_wait(&taskReady, &queueMutex);
    }
    int requestId=generateRequestId();
    GradingRequest request;
    request.id = requestId;
    request.programFile = makeProgramFileName(requestId);
    request.execFile = makeExecFileName(requestId);
    request.status = "In Queue";
    gradingRequests[requestId] = request;
    taskQueue.push(sockfd);
    taskCount++;
    pthread_cond_signal(&taskReady);
    pthread_mutex_unlock(&queueMutex);

    // Send response to the client
    send(sockfd, ("Your grading request ID " + std::to_string(requestId) + " has been accepted. It is currently at position " +
                  std::to_string(taskQueue.size()) + " in the queue.\n").c_str(), 150,0);
}

int main(int argc, char *argv[]) {
    int sockfd, newsockfd, portno;
    socklen_t clilen;
    struct sockaddr_in serv_addr, cli_addr;

    if (argc < 3) {
        fprintf(stderr, "ERROR, no port provided\n");
        exit(1);
    }

    sockfd = socket(AF_INET, SOCK_STREAM, 0);

    if (sockfd < 0)
        perror("ERROR opening socket");

    bzero(reinterpret_cast<char *>(&serv_addr), sizeof(serv_addr));

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    portno = atoi(argv[1]);
    serv_addr.sin_port = htons(portno);

    if (bind(sockfd, reinterpret_cast<struct sockaddr *>(&serv_addr), sizeof(serv_addr)) < 0){
        perror("ERROR on binding");
        return -1;
    }

    listen(sockfd, 1);

    clilen = sizeof(cli_addr);

   int requestId;
    pthread_t threads[atoi(argv[2])];
    pthread_mutex_init(&queueMutex, nullptr);
    pthread_mutex_init(&taskMutex, nullptr);
    pthread_cond_init(&taskReady, nullptr);

    for (int i = 0; i < atoi(argv[2]); i++) {
        if (pthread_create(&threads[i], nullptr, &workerFunc, (void *)requestId) != 0) {
            printf("ERROR: Could not create thread %d", i);
            exit(EXIT_FAILURE);
        }
    }

    while (1) {
        newsockfd = accept(sockfd, reinterpret_cast<struct sockaddr *>(&cli_addr), &clilen);
        if (newsockfd < 0)
            perror("ERROR on accept");
        masterFunc(newsockfd);
    }

    done = true;

    for (int i = 0; i < atoi(argv[2]); i++) {
        if (pthread_join(threads[i], nullptr) != 0) {
            printf("ERROR: Could not join thread %d", i);
            exit(EXIT_FAILURE);
        }
    }

    return 0;
}

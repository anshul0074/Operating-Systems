#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>

const int BUFFER_SIZE = 1024;
const int MAX_FILE_SIZE_BYTES = 4;
const int MAX_TRIES = 5;

int send_file(int sockfd, const std::string &file_path);
void error(const std::string &msg);

void checkStatus(int sockfd, int requestId) {
    std::cout<<"here\n";
    // Send a status inquiry to the server
    send(sockfd, ("X" + std::to_string(requestId)).c_str(), ("X" + std::to_string(requestId)).length(), 0);


    // Receive and print the status response
    char buffer[BUFFER_SIZE];
    std::memset(buffer, 0, BUFFER_SIZE);
    size_t bytes_read = recv(sockfd, buffer, BUFFER_SIZE, 0);
    if (bytes_read > 0) {
        std::cout << "Server Response: " << buffer << std::endl;
    } else {
        std::cout << "Error receiving status response" << std::endl;
    }
}

int main(int argc, char *argv[]) {
    if (argc != 5) {
        error("Usage: ./submit <new|status> <serverIP> <port> <sourceCodeFileTobeGraded|requestID>");
    }

    std::string action = argv[1];
    std::string server_ip = argv[2];
    int server_port = std::stoi(argv[3]);
    std::string file_path = argv[4];

    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        error("Socket creation failed");
    }

    struct sockaddr_in serv_addr;
    std::memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(server_port);
    inet_pton(AF_INET, server_ip.c_str(), &serv_addr.sin_addr.s_addr);

    int tries = 0;
    while (true) {
        if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) == 0) {
            break;
        }
        sleep(1);
        tries += 1;
        if (tries == MAX_TRIES) {
            std::cout << "Server not responding" << std::endl;
            return -1;
        }
    }

    if (action == "new") {
        std::string file_path = argv[4];
        if (send_file(sockfd, file_path) != 0) {
            std::cout << "Error sending source file" << std::endl;
            close(sockfd);
            return -1;
        }

        std::cout << "Code sent for grading " << std::endl;
    } else if (action == "status") {
        int requestId = std::stoi(argv[4]);
        checkStatus(sockfd, requestId);
    } else {
        error("Invalid action. Use 'new' for a new request or 'status' for status inquiry.");
    }

    
    size_t bytes_read;
    char buffer[BUFFER_SIZE];
    std::memset(buffer, 0, BUFFER_SIZE);  // Replaced bzero with std::memset
    while (true) {
        bytes_read = recv(sockfd, buffer, BUFFER_SIZE, 0);
        if (bytes_read <= 0) {
            break;
        }
        std::cout << "Server Response: " << buffer << std::endl;
        std::memset(buffer, 0, BUFFER_SIZE);  // Replaced bzero with std::memset
    }

    close(sockfd);
    return 0;
}

// ... (unchanged)

int send_file(int sockfd, const std::string &file_path) {
    char buffer[BUFFER_SIZE];
    std::memset(buffer, 0, BUFFER_SIZE);  // Replaced bzero with std::memset

    std::ifstream file(file_path, std::ios::binary);
    if (!file.is_open()) {
        error("Error opening file");
    }

    file.seekg(0, std::ios::end);
    int file_size = file.tellg();
    file.seekg(0, std::ios::beg);

    std::cout << "File size is: " << file_size << std::endl;

    char file_size_bytes[MAX_FILE_SIZE_BYTES];
    std::memcpy(file_size_bytes, &file_size, sizeof(file_size_bytes));  // Added #include <cstring>

    if (send(sockfd, &file_size_bytes, sizeof(file_size_bytes), 0) == -1) {
        error("Error sending file size");
    }

    while (!file.eof()) {
        size_t bytes_read = file.read(buffer, BUFFER_SIZE).gcount();
        if (send(sockfd, buffer, bytes_read, 0) == -1) {
            error("Error sending file data");
        }
    }

    file.close();
    return 0;
}

void error(const std::string &msg) {
    std::cerr << msg << std::endl;
    exit(1);
}

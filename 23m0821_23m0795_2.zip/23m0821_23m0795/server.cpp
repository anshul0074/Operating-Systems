#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <cstring>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <unistd.h>
#include <queue>
#include <mutex>
#include <condition_variable>
#include <unordered_map>
#include <chrono>

std::queue<int> connectionQueue;
std::mutex queueMutex;
std::condition_variable cv;

struct GradingResult {
    std::string result;
    std::string details;
};

struct GradingRequest {
    std::chrono::system_clock::time_point timestamp;
    std::string status;
    GradingResult result;
};

std::unordered_map<std::string, GradingRequest> gradingRequests;
std::mutex gradingMutex;


void compileAndGrade(const std::string& sourceCode, int clientSocket, const std::string& requestId) {
    GradingResult gradingResult;

    {
        std::unique_lock<std::mutex> lock(gradingMutex);
        gradingRequests[requestId].status = "QUEUED";
        gradingRequests[requestId].timestamp = std::chrono::system_clock::now();
    }
    // Compile the source code
    int compileResult = system("g++ -o program source_code.cpp 2> compiler_error.txt");
    if (compileResult != 0) {
        std::string errorMessage = "COMPILER ERROR\n";

        // Read and send the compiler error details back to the client
        std::ifstream compilerErrorFile("compiler_error.txt");
        std::string compilerError((std::istreambuf_iterator<char>(compilerErrorFile)), std::istreambuf_iterator<char>());
        errorMessage += compilerError;

        gradingResult.result = errorMessage;
    } else {
        // Run the executable
        int runResult = system("./program > program_output.txt 2> runtime_error.txt");
        if (runResult != 0) {
            std::string errorMessage = "RUNTIME ERROR\n";

            // Read and send the runtime error details back to the client
            std::ifstream runtimeErrorFile("runtime_error.txt");
            std::string runtimeError((std::istreambuf_iterator<char>(runtimeErrorFile)), std::istreambuf_iterator<char>());
            errorMessage += runtimeError;

            gradingResult.result = errorMessage;
        } else {
            // Capture the program output
            std::string programOutput;
            std::ifstream programOutputFile("program_output.txt");
            programOutput.assign((std::istreambuf_iterator<char>(programOutputFile)), std::istreambuf_iterator<char>());

            std::string expectedOutput = "1 2 3 4 5 6 7 8 9 10"; // Your expected output

            if (programOutput == expectedOutput) {
                gradingResult.result = "PASS\n";
            } else {
                std::string errorMessage = "OUTPUT ERROR\n";

                // Compare programOutput with expectedOutput and send differences back to the client
                gradingResult.result = errorMessage;

                // Find and store the differences between programOutput and expectedOutput
                std::string differences;
                for (size_t i = 0; i < programOutput.length() && i < expectedOutput.length(); ++i) {
                    differences += "Mismatch at position " + std::to_string(i) + ": ";
                    differences += "Expected '" + std::string(1, expectedOutput[i]) + "', but got '" + std::string(1, programOutput[i]) + "'\n";
                }

                gradingResult.details = differences;
            }
        }
    }
    gradingRequests[requestId].status="COMPLETED";
    // Save results to results.txt
    {
        std::ofstream resultsFile("results.txt", std::ios_base::app); // Open the file in append mode
        resultsFile << "Request ID: " << requestId << "\n";
        resultsFile << "Timestamp: " << std::chrono::system_clock::to_time_t(gradingRequests[requestId].timestamp) << "\n";
        resultsFile << "Status: " << gradingRequests[requestId].status << "\n";
        resultsFile << "Result: " << gradingResult.result << "\n";
        resultsFile << "Details: " << gradingResult.details << "\n";
        resultsFile << "------------------------------------\n";
        resultsFile.close();
    }
    // Send the appropriate response back to the client
    std::string response;
    {
        std::unique_lock<std::mutex> lock(gradingMutex);
        if (gradingRequests.find(requestId) != gradingRequests.end()) {
            if (gradingRequests[requestId].status == "QUEUED") {
                response = "Your grading request ID " + requestId + " has been accepted. It is currently at position " + std::to_string(connectionQueue.size()) + " in the queue.\n";
            } else if (gradingRequests[requestId].status == "COMPLETED") {
                response = "Grading request " + requestId + " processing is done, here are the results:\n" + gradingResult.result;
            } else {
                // Handle other possible statuses
                response = "Your grading request ID" + requestId + "has been accepted and is currently being processed\n";
            }
        } else {
            response = "Grading request " + requestId + " not found. Please check and resend your request ID or re-send your original grading request.\n";
        }
    }

    if (send(clientSocket, response.c_str(), response.size(), 0) == -1) {
        std::cerr << "Sending grading response to client failed." << std::endl;
    }
}

void* workerThread(void* arg) {
    while (true) {
        int clientSocket = -1;

        // Dequeue a connection from the shared queue
        {
            std::unique_lock<std::mutex> lock(queueMutex);
            cv.wait(lock, [] { return !connectionQueue.empty(); });
            clientSocket = connectionQueue.front();
            connectionQueue.pop();
        }

        if (clientSocket != -1) {
            // Process the grading request
            // Receive request ID and source code from the client
            char buffer[1024];
            bzero(buffer, sizeof(buffer));
            if (recv(clientSocket, buffer, sizeof(buffer), 0) == -1) {
                std::cerr << "Receiving request ID and source code from client failed." << std::endl;
                close(clientSocket);
            } else {
                std::string requestData(buffer);
                size_t pos = requestData.find("\n");
                if (pos != std::string::npos) {
                    std::string requestId = requestData.substr(0, pos);
                    std::string sourceCode = requestData.substr(pos + 1);
                    compileAndGrade(sourceCode, clientSocket, requestId);
                } else {
                    std::cerr << "Invalid request format received from client." << std::endl;
                }
            }
            close(clientSocket);
        }
    }
}
int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cerr << "Usage: " << argv[0] << " <port> <thread_pool_size>" << std::endl;
        return 1;
    }

    int port = std::atoi(argv[1]);
    int threadPoolSize = std::atoi(argv[2]);

    // Create the server socket
    int serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == -1) {
        std::cerr << "Socket creation error." << std::endl;
        return 1;
    }

    struct sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(port);
    serverAddr.sin_addr.s_addr = INADDR_ANY;

    if (bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == -1) {
        std::cerr << "Binding error." << std::endl;
        return 1;
    }

    if (listen(serverSocket, 10) == -1) {
        std::cerr << "Listening error." << std::endl;
        return 1;
    }

    // Create and start the worker threads
    pthread_t threads[threadPoolSize];
    for (int i = 0; i < threadPoolSize; ++i) {
        pthread_create(&threads[i], NULL, workerThread, NULL);
    }
    while (true) {
        // Accept incoming connections and enqueue them
        struct sockaddr_in clientAddr;
        socklen_t clientAddrLen = sizeof(clientAddr);
        int clientSocket = accept(serverSocket, (struct sockaddr*)&clientAddr, &clientAddrLen);
        if (clientSocket != -1) {
            {
                std::unique_lock<std::mutex> lock(queueMutex);
                connectionQueue.push(clientSocket);
            }
            cv.notify_one(); // Notify a waiting worker thread
        }
    }

    // Close the server socket and exit
    close(serverSocket);
    return 0;
}
